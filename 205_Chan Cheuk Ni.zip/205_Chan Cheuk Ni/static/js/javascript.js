// pop-up window when user clicks the submit the Feedback form
function Submit() {
  window.alert("Thanks for your comment !");
  window.location.assign("Home")
}

// signup modal 
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// show password when Login
function showPassword() {
  var passwd = document.getElementById("myInput");
  if (passwd.type === "password") {
    passwd.type = "text";
  } else {
    passwd.type = "password";
  }
}
